summary.peperr <- function(object, ...){
   print(object)
}

