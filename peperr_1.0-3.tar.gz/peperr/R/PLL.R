`PLL` <-
function(object, newdata, newtime, newstatus, ...){
   UseMethod("PLL", object)
}

