predictProb <- function (object, response, x, ...)
{
    UseMethod("predictProb")
}
